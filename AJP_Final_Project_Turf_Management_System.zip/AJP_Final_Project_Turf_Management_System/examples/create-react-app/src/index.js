import { greatCircle, point } from "@turf/turf";

console.log(greatCircle([0, 0], [100, 10]));
console.log(point([100, 0]));
