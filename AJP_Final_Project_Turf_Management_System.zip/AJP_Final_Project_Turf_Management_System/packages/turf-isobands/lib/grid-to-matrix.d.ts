declare module "grid-to-matrix";

declare function gridToMatrix(grid: any, options: any): any;

export { gridToMatrix };
export default gridToMatrix;
