declare module "marchingsquares";
